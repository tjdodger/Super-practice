var sentence = prompt('plz give txt');
function capLet(a){
  var text = '';
  var splitSen = sentence.split('');
  console.log(splitSen);
  for(var i=0;i<sentence.length;i++){
    var newsen = splitSen[i].toUpperCase(splitSen);
    splitSen.push(text);
    
  }
}
console.log(capLet(sentence));